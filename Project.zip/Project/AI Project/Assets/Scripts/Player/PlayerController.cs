﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    public float speed = 7;

    private Rigidbody rb;
    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }



    // Update is called once per frame
    void FixedUpdate()
    {

        ApplyMovement();

        if (Input.GetButtonDown("Sprint"))
        {
            speed = 10;
        }
        else
        {
            speed = 7;
        }

    }
    private void ApplyMovement()
    {
        float xAxis = Input.GetAxis("Horizontal"), zAxis = Input.GetAxis("Vertical");

        float x = xAxis * speed * Time.deltaTime;

        float z = zAxis * speed * Time.deltaTime;

        transform.Translate(x, 0, z);
    }

}
